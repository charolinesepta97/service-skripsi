package com.packt.webstore.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Cis {
	public int id;
	@NotNull(message= " {NotNull.Cis.no_cis.validation}") 
	@Size(min=8, max=8, message=" {Size.Cis.no_cis.validation}")
	public String no_cis;
	
	@Size(min=10, max=10, message=" {Size.Cis.no_rekening.validation}") 
	@NotNull(message= " {NotNull.Cis.no_rekening.validation}")
	public String no_rekening;
	
	@Size(min=16, max=16, message=" {Size.Cis.no_identitas.validation}")
	@NotNull(message= " {NotNull.Cis.no_identitas.validation}")
	public String no_identitas;
	
	@Size(min=1, max=50, message=" {Size.Cis.nama_nasabah.validation}") 
	@NotNull(message= " {NotNull.Cis.nama_nasabah.validation}")
	public String nama_nasabah;
	
	@Size(min=1, max=12, message=" {Size.Cis.telpon.validation}") 
	@NotNull(message= " {NotNull.Cis.telpon.validation}")
	public String telpon;
	
	@Size(min=1, max=250, message=" {Size.Cis.alamat.validation}") 
	@NotNull(message= " {NotNull.Cis.alamat.validation}")
	public String alamat;
	
	public String tipe_nasabah;

	public Cis() {

	}

	public Cis(int id, String no_cis, String no_rekening, String no_identitas, String nama_nasabah, String telpon,
			String alamat, String tipe_nasabah) {
		super();
		this.id = id;
		this.no_cis = no_cis;
		this.no_rekening = no_rekening;
		this.no_identitas = no_identitas;
		this.nama_nasabah = nama_nasabah;
		this.telpon = telpon;
		this.alamat = alamat;
		this.tipe_nasabah = tipe_nasabah;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNo_cis() {
		return no_cis;
	}

	public void setNo_cis(String no_cis) {
		this.no_cis = no_cis;
	}

	public String getNo_rekening() {
		return no_rekening;
	}

	public void setNo_rekening(String no_rekening) {
		this.no_rekening = no_rekening;
	}

	public String getNo_identitas() {
		return no_identitas;
	}

	public void setNo_identitas(String no_identitas) {
		this.no_identitas = no_identitas;
	}

	public String getNama_nasabah() {
		return nama_nasabah;
	}

	public void setNama_nasabah(String nama_nasabah) {
		this.nama_nasabah = nama_nasabah;
	}

	public String getTelpon() {
		return telpon;
	}

	public void setTelpon(String telpon) {
		this.telpon = telpon;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getTipe_nasabah() {
		return tipe_nasabah;
	}

	public void setTipe_nasabah(String tipe_nasabah) {
		this.tipe_nasabah = tipe_nasabah;
	}
}
