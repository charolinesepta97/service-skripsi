package com.packt.webstore.service;

import com.packt.webstore.domain.Cis;

public interface CisService {
	void addCis(Cis cis);

	Cis getCisById(int Id);

	void updateCis(int Id, Cis cis);
}
