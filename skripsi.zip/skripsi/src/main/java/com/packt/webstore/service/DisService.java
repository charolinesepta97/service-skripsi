package com.packt.webstore.service;

import com.packt.webstore.domain.Dis;

public interface DisService {
	void addDis(Dis dis);

	Dis getDisById(int Id);

	void updateDis(int Id, Dis dis);
}
