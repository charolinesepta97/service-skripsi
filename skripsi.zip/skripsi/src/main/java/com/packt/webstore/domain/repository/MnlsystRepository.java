package com.packt.webstore.domain.repository;

import java.util.List;

import com.packt.webstore.domain.Mnlsyst;

public interface MnlsystRepository {
	List<Mnlsyst> getAllMnlsyst();

	void addMnlsyst(Mnlsyst mnlsyst);
	
	void updateMnlsyst(int Id, Mnlsyst mnlsyst);

	Mnlsyst getMnlsystById(int Id);
}
