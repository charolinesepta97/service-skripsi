package com.packt.webstore.service;

import com.packt.webstore.domain.Mnlsyst;

public interface MnlsystService {
	void addMnlsyst(Mnlsyst mnlsyst);

	Mnlsyst getMnlsystById(int Id);

	void updateMnlsyst(int Id, Mnlsyst mnlsyst);
}
