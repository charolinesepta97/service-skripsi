package com.packt.webstore.domain.repository;

import java.util.List;

import com.packt.webstore.domain.Dis;

public interface DisRepository {
	List<Dis> getAllDis();

	void addDis(Dis dis);
	
	void updateDis(int Id, Dis dis);

	Dis getDisById(int Id);
}
