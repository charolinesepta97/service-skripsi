package com.packt.webstore.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.packt.webstore.domain.Cis;
import com.packt.webstore.domain.repository.CisRepository;
import com.packt.webstore.service.CisService;

@Controller
public class CisController {
	@Autowired
	private CisRepository cisRepository;

	@Autowired
	private CisService cisService;


	@RequestMapping("/allCis")
	public String list(Model model) {
		model.addAttribute("cis", cisRepository.getAllCis());
		return "allCis";
	}

	@RequestMapping(value = "/cis/add", method = RequestMethod.GET)
	public String getAddNewCisForm(Model model) {
		Cis newCis = new Cis();
		model.addAttribute("newCis", newCis);
		return "addCis";
	}

	@RequestMapping(value = "/cis/add", method = RequestMethod.POST)
	public String processAddNewCisForm(@ModelAttribute("newCis") @Valid Cis newCis, BindingResult result, HttpServletRequest request) {
		if(result.hasErrors()) {
		      return "addCis";
		}
		cisService.addCis(newCis);
		return "redirect:/allCis";
	}

	@RequestMapping("/cis")
	public String getCisById(@RequestParam("id") int Id, Model model) {
		model.addAttribute("cis", cisService.getCisById(Id));
		return "cis";
	}

	 
}
