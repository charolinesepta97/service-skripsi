package com.packt.webstore.domain;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Dis {
	public int id;
	
	@NotNull(message= " {NotNull.Dis.no_cis.validation}") 
	@Size(min=8, max=8, message=" {Size.Dis.no_cis.validation}")
	public String no_cis;
	
	@Size(min=10, max=10, message=" {Size.Dis.no_rekening.validation}") 
	@NotNull(message= " {NotNull.Dis.no_rekening.validation}")
	public String no_rekening;
	
	@Size(min=16, max=16, message=" {Size.Dis.no_identitas.validation}")
	@NotNull(message= " {NotNull.Dis.no_identitas.validation}")
	public String no_identitas;
	
	@Size(min=1, max=50, message=" {Size.Dis.nama_nasabah.validation}") 
	@NotNull(message= " {NotNull.Dis.nama_nasabah.validation}")
	public String nama_nasabah;
	
	@Size(min=1, max=12, message=" {Size.Dis.telpon.validation}") 
	@NotNull(message= " {NotNull.Dis.telpon.validation}")
	public String telpon;
	
	@Size(min=1, max=250, message=" {Size.Dis.alamat.validation}") 
	@NotNull(message= " {NotNull.Dis.alamat.validation}")
	public String alamat;
	
	@Min(value=0, message=" {Min.Product.Cis.validation}")
	@Digits(integer=16, fraction=2, message=" {Digits.Cis.tunggakan.validation}")
	@NotNull(message= " {NotNull.Cis.tunggakan.validation}")
	public int tunggakan;

	public Dis() {

	}

	public Dis(int id, String no_cis, String no_rekening, String no_identitas, String nama_nasabah, String telpon,
			String alamat, int tunggakan) {
		super();
		this.id = id;
		this.no_cis = no_cis;
		this.no_rekening = no_rekening;
		this.no_identitas = no_identitas;
		this.nama_nasabah = nama_nasabah;
		this.telpon = telpon;
		this.alamat = alamat;
		this.tunggakan = tunggakan;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNo_cis() {
		return no_cis;
	}

	public void setNo_cis(String no_cis) {
		this.no_cis = no_cis;
	}

	public String getNo_rekening() {
		return no_rekening;
	}

	public void setNo_rekening(String no_rekening) {
		this.no_rekening = no_rekening;
	}

	public String getNo_identitas() {
		return no_identitas;
	}

	public void setNo_identitas(String no_identitas) {
		this.no_identitas = no_identitas;
	}

	public String getNama_nasabah() {
		return nama_nasabah;
	}

	public void setNama_nasabah(String nama_nasabah) {
		this.nama_nasabah = nama_nasabah;
	}

	public String getTelpon() {
		return telpon;
	}

	public void setTelpon(String telpon) {
		this.telpon = telpon;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public int getTunggakan() {
		return tunggakan;
	}

	public void setTunggakan(int tunggakan) {
		this.tunggakan = tunggakan;
	}
}
