package com.packt.webstore.domain.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.packt.webstore.domain.Cis;
import com.packt.webstore.domain.repository.CisRepository;

@Repository
public class InMemoryCisRepository implements CisRepository {
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Override
	public List<Cis> getAllCis() {
		Map<String, Object> params = new HashMap<String, Object>();
		List<Cis> result = jdbcTemplate.query("SELECT * FROM cis", params, new CisMapper());
		return result;
	}

	public static final class CisMapper implements RowMapper<Cis> {
		public Cis mapRow(ResultSet rs, int rowNum) throws SQLException {
			Cis cis = new Cis();
			cis.setId(rs.getInt("ID"));
			cis.setNo_cis(rs.getString("NO_CIS"));
			cis.setNo_rekening(rs.getString("NO_REKENING"));
			cis.setNo_identitas(rs.getString("NO_IDENTITAS"));
			cis.setNama_nasabah(rs.getString("NAMA_NASABAH"));
			cis.setAlamat(rs.getString("ALAMAT"));
			cis.setTelpon(rs.getString("TELPON"));
			cis.setTipe_nasabah(rs.getString("TIPE_NASABAH"));
			return cis;

		}
	}

	@Override
	public void addCis(Cis cis) {
		String SQL = "INSERT INTO CIS (" + "NO_CIS," + "NO_REKENING," + "NO_IDENTITAS," + "NAMA_NASABAH," + "ALAMAT,"
				+ "TELPON," + "TIPE_NASABAH) "
				+ "VALUES (:no_cis, :no_rekening, :no_identitas, :nama_nasabah, :alamat, :telpon, :tipe_nasabah)";
		Map<String, Object> params = new HashMap<>();
		params.put("no_cis", cis.getNo_cis());
		params.put("no_rekening", cis.getNo_rekening());
		params.put("no_identitas", cis.getNo_identitas());
		params.put("nama_nasabah", cis.getNama_nasabah());
		params.put("alamat", cis.getAlamat());
		params.put("telpon", cis.getTelpon());
		params.put("tipe_nasabah", cis.getTipe_nasabah());
		jdbcTemplate.update(SQL, params);
	}

	@Override
	public Cis getCisById(int Id) {
		String SQL = "SELECT * FROM CIS WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", Id);
		return jdbcTemplate.queryForObject(SQL, params, new CisMapper());
	}

	@Override
	public void updateCis(int Id, Cis cis) {
		// TODO Auto-generated method stub
		String SQL = "UPDATE CIS SET NO_CIS = :no_cis, NO_REKENING = :no_rekening, NO_IDENTITAS = :no_identitas, NAMA_NASABAH = :nama_nasabah, "
				+ "ALAMAT = :alamat, TELPON = :telpon, TIPE_NASABAH = :tipe_nasabah WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("no_cis", cis.getNo_cis());
		params.put("no_rekening", cis.getNo_rekening());
		params.put("no_identitas", cis.getNo_identitas());
		params.put("nama_nasabah", cis.getNama_nasabah());
		params.put("alamat", cis.getAlamat());
		params.put("telpon", cis.getTelpon());
		params.put("tipe_nasabah", cis.getTipe_nasabah());
		params.put("id", Id);
		jdbcTemplate.update(SQL, params);
	}

}
