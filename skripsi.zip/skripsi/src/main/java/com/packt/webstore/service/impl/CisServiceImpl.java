package com.packt.webstore.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packt.webstore.domain.Cis;
import com.packt.webstore.domain.repository.CisRepository;
import com.packt.webstore.service.CisService;
@Service
public class CisServiceImpl implements CisService {

	@Autowired
	CisRepository cisRepository;

	@Override
	public void addCis(Cis cis) {
		// TODO Auto-generated method stub
		cisRepository.addCis(cis);
	}

	@Override
	public Cis getCisById(int Id) {
		// TODO Auto-generated method stub
		return cisRepository.getCisById(Id);
	}

	@Override
	public void updateCis(int Id, Cis cis) {
		// TODO Auto-generated method stub
		cisRepository.updateCis(Id, cis);
	}
}
