package com.packt.webstore.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packt.webstore.domain.Mnlsyst;
import com.packt.webstore.domain.repository.MnlsystRepository;
import com.packt.webstore.service.MnlsystService;
@Service
public class MnlsystServiceImpl implements MnlsystService {

	@Autowired
	MnlsystRepository mnlSystRepository;

	@Override
	public void addMnlsyst(Mnlsyst mnlsyst) {
		// TODO Auto-generated method stub
		mnlSystRepository.addMnlsyst(mnlsyst);
	}

	@Override
	public Mnlsyst getMnlsystById(int Id) {
		// TODO Auto-generated method stub
		return mnlSystRepository.getMnlsystById(Id);
	}

	@Override
	public void updateMnlsyst(int Id, Mnlsyst mnlsyst) {
		// TODO Auto-generated method stub
		mnlSystRepository.updateMnlsyst(Id, mnlsyst);
	}
}
