package com.packt.webstore.domain.repository;

import java.util.List;

import com.packt.webstore.domain.Cis;

public interface CisRepository {
	List<Cis> getAllCis();

	void addCis(Cis cis);
	
	void updateCis(int Id, Cis cis);

	Cis getCisById(int Id);
	
}
