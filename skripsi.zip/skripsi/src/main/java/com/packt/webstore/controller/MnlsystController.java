package com.packt.webstore.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.packt.webstore.domain.Dis;
import com.packt.webstore.domain.Mnlsyst;
import com.packt.webstore.domain.repository.MnlsystRepository;
import com.packt.webstore.service.MnlsystService;

@Controller
public class MnlsystController {
	@Autowired
	private MnlsystRepository mnlsystRepository;

	@Autowired
	private MnlsystService mnlsystService;

	@RequestMapping("/allMnlsyst")
	public String list(Model model) {
		model.addAttribute("mnlsyst", mnlsystRepository.getAllMnlsyst());
		return "allMnlsyst";
	}

	@RequestMapping(value = "/mnlsyst/add", method = RequestMethod.GET)
	public String getAddNewMnlsystForm(Model model) {
		Mnlsyst newMnlsyst = new Mnlsyst();
		model.addAttribute("newMnlsyst", newMnlsyst);
		return "addMnlsyst";
	}

	@RequestMapping(value = "/mnlsyst/add", method = RequestMethod.POST)
	public String processAddNewMnlsystForm(@ModelAttribute("newMnlsyst") @Valid Mnlsyst newMnlsyst, BindingResult result, HttpServletRequest request) {
		if(result.hasErrors()) {
		      return "addMnlsyst";
		}
		mnlsystService.addMnlsyst(newMnlsyst);
		return "redirect:/allMnlsyst";
	}

	@RequestMapping("/mnlsyst")
	public String getMnlsystById(@RequestParam("id") int Id, Model model) {
		model.addAttribute("mnlsyst", mnlsystService.getMnlsystById(Id));
		return "mnlsyst";
	}
}
