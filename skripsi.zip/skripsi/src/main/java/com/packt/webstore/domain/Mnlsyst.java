package com.packt.webstore.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Mnlsyst {
	public int id;
	
	@NotNull(message= " {NotNull.Mnlsyst.no_cis.validation}") 
	@Size(min=8, max=8, message=" {Size.Mnlsyst.no_cis.validation}")
	public String no_cis;
	
	@Size(min=10, max=10, message=" {Size.Mnlsyst.no_rekening.validation}") 
	@NotNull(message= " {NotNull.Mnlsyst.no_rekening.validation}")
	public String no_rekening;
	
	@Size(min=16, max=16, message=" {Size.Mnlsyst.no_identitas.validation}")
	@NotNull(message= " {NotNull.Mnlsyst.no_identitas.validation}")
	public String no_identitas;
	
	@Size(min=1, max=50, message=" {Size.Mnlsyst.nama_nasabah.validation}") 
	@NotNull(message= " {NotNull.Mnlsyst.nama_nasabah.validation}")
	public String nama_nasabah;
	
	@Size(min=1, max=12, message=" {Size.Mnlsyst.telpon.validation}") 
	@NotNull(message= " {NotNull.Mnlsyst.telpon.validation}")
	public String telpon;
	
	@Size(min=1, max=250, message=" {Size.Mnlsyst.alamat.validation}") 
	@NotNull(message= " {NotNull.Mnlsyst.alamat.validation}")
	public String alamat;
	
	
	public String alasan;
	
	public Mnlsyst(int id, String no_cis, String no_rekening, String no_identitas, String nama_nasabah, String telpon,
			String alamat, String alasan) {
		super();
		this.id = id;
		this.no_cis = no_cis;
		this.no_rekening = no_rekening;
		this.no_identitas = no_identitas;
		this.nama_nasabah = nama_nasabah;
		this.telpon = telpon;
		this.alamat = alamat;
		this.alasan = alasan;
	}
	
	public Mnlsyst() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNo_cis() {
		return no_cis;
	}

	public void setNo_cis(String no_cis) {
		this.no_cis = no_cis;
	}

	public String getNo_rekening() {
		return no_rekening;
	}

	public void setNo_rekening(String no_rekening) {
		this.no_rekening = no_rekening;
	}

	public String getNo_identitas() {
		return no_identitas;
	}

	public void setNo_identitas(String no_identitas) {
		this.no_identitas = no_identitas;
	}

	public String getNama_nasabah() {
		return nama_nasabah;
	}

	public void setNama_nasabah(String nama_nasabah) {
		this.nama_nasabah = nama_nasabah;
	}

	public String getTelpon() {
		return telpon;
	}

	public void setTelpon(String telpon) {
		this.telpon = telpon;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getAlasan() {
		return alasan;
	}

	public void setAlasan(String alasan) {
		this.alasan = alasan;
	}
	
}
