package com.packt.webstore.domain.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.packt.webstore.domain.Mnlsyst;
import com.packt.webstore.domain.repository.MnlsystRepository;

@Repository
public class InMemoryMnlsystRepository implements MnlsystRepository {
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Override
	public List<Mnlsyst> getAllMnlsyst() {
		Map<String, Object> params = new HashMap<String, Object>();
		List<Mnlsyst> result = jdbcTemplate.query("SELECT * FROM mnlsyst", params, new MnlsystMapper());
		return result;
	}

	public static final class MnlsystMapper implements RowMapper<Mnlsyst> {
		public Mnlsyst mapRow(ResultSet rs, int rowNum) throws SQLException {
			Mnlsyst mnlsyst = new Mnlsyst();
			mnlsyst.setId(rs.getInt("ID"));
			mnlsyst.setNo_cis(rs.getString("NO_CIS"));
			mnlsyst.setNo_rekening(rs.getString("NO_REKENING"));
			mnlsyst.setNo_identitas(rs.getString("NO_IDENTITAS"));
			mnlsyst.setNama_nasabah(rs.getString("NAMA_NASABAH"));
			mnlsyst.setAlamat(rs.getString("ALAMAT"));
			mnlsyst.setTelpon(rs.getString("TELPON"));
			mnlsyst.setAlasan(rs.getString("ALASAN"));
			return mnlsyst;

		}
	}

	@Override
	public void addMnlsyst(Mnlsyst mnlsyst) {
		String SQL = "INSERT INTO MNLSYST (" + "NO_CIS," + "NO_REKENING," + "NO_IDENTITAS," + "NAMA_NASABAH," + "ALAMAT,"
				+ "TELPON," + "ALASAN) "
				+ "VALUES (:no_cis, :no_rekening, :no_identitas, :nama_nasabah, :alamat, :telpon, :alasan)";
		Map<String, Object> params = new HashMap<>();
		params.put("no_cis", mnlsyst.getNo_cis());
		params.put("no_rekening", mnlsyst.getNo_rekening());
		params.put("no_identitas", mnlsyst.getNo_identitas());
		params.put("nama_nasabah", mnlsyst.getNama_nasabah());
		params.put("alamat", mnlsyst.getAlamat());
		params.put("telpon", mnlsyst.getTelpon());
		params.put("alasan", mnlsyst.getAlasan());
		jdbcTemplate.update(SQL, params);
	}

	@Override
	public Mnlsyst getMnlsystById(int Id) {
		String SQL = "SELECT * FROM MNLSYST WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", Id);
		return jdbcTemplate.queryForObject(SQL, params, new MnlsystMapper());
	}

	@Override
	public void updateMnlsyst(int Id, Mnlsyst mnlsyst) {
		// TODO Auto-generated method stub
		String SQL = "UPDATE MNLSYST SET NO_CIS = :no_cis, NO_REKENING = :no_rekening, NO_IDENTITAS = :no_identitas, NAMA_NASABAH = :nama_nasabah, "
				+ "ALAMAT = :alamat, TELPON = :telpon, TUNGGAKAN = :tunggakan WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("no_cis", mnlsyst.getNo_cis());
		params.put("no_rekening", mnlsyst.getNo_rekening());
		params.put("no_identitas", mnlsyst.getNo_identitas());
		params.put("nama_nasabah", mnlsyst.getNama_nasabah());
		params.put("alamat", mnlsyst.getAlamat());
		params.put("telpon", mnlsyst.getTelpon());
		params.put("id", Id);
		jdbcTemplate.update(SQL, params);
	}

}
