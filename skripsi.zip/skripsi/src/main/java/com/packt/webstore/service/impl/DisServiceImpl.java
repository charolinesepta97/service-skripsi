package com.packt.webstore.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packt.webstore.domain.Dis;
import com.packt.webstore.domain.repository.DisRepository;
import com.packt.webstore.service.DisService;
@Service
public class DisServiceImpl implements DisService {

	@Autowired
	DisRepository disRepository;

	@Override
	public void addDis(Dis dis) {
		// TODO Auto-generated method stub
		disRepository.addDis(dis);
	}

	@Override
	public Dis getDisById(int Id) {
		// TODO Auto-generated method stub
		return disRepository.getDisById(Id);
	}

	@Override
	public void updateDis(int Id, Dis dis) {
		// TODO Auto-generated method stub
		disRepository.updateDis(Id, dis);
	}
}
