package com.packt.webstore.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.packt.webstore.domain.Cis;
import com.packt.webstore.domain.Dis;
import com.packt.webstore.domain.repository.DisRepository;
import com.packt.webstore.service.DisService;

@Controller
public class DisController {
	@Autowired
	private DisRepository disRepository;

	@Autowired
	private DisService disService;

	@RequestMapping("/allDis")
	public String list(Model model) {
		model.addAttribute("dis", disRepository.getAllDis());
		return "allDis";
	}

	@RequestMapping(value = "/dis/add", method = RequestMethod.GET)
	public String getAddNewDisForm(Model model) {
		Dis newDis = new Dis();
		model.addAttribute("newDis", newDis);
		return "addDis";
	}

	@RequestMapping(value = "/dis/add", method = RequestMethod.POST)
	public String processAddNewDisForm(@ModelAttribute("newDis") @Valid Dis newDis, BindingResult result, HttpServletRequest request) {
		if(result.hasErrors()) {
		      return "addDis";
		}
		disService.addDis(newDis);
		return "redirect:/allDis";
	}

	@RequestMapping("/dis")
	public String getDisById(@RequestParam("id") int Id, Model model) {
		model.addAttribute("dis", disService.getDisById(Id));
		return "dis";
	}
	
	@RequestMapping(value = "/dis/update/{Id}", method = RequestMethod.GET)
	public String getUpdateeDisForm(@PathVariable(value = "Id") int Id, Model model) {
		model.addAttribute("dis", disService.getDisById(Id));
		return "updateDis";
	}

	@RequestMapping(value = "/dis/update/{Id}", method = RequestMethod.PUT)
	public String updateDis(@PathVariable(value = "Id") int Id, @RequestBody Dis existsDis) {
		disService.updateDis(Id, existsDis);
		return "redirect:/allDis";
	}
}
