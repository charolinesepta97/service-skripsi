package com.packt.webstore.domain.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.packt.webstore.domain.Dis;
import com.packt.webstore.domain.repository.DisRepository;

@Repository
public class InMemoryDisRepository implements DisRepository {
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Override
	public List<Dis> getAllDis() {
		Map<String, Object> params = new HashMap<String, Object>();
		List<Dis> result = jdbcTemplate.query("SELECT * FROM dis", params, new DisMapper());
		return result;
	}

	public static final class DisMapper implements RowMapper<Dis> {
		public Dis mapRow(ResultSet rs, int rowNum) throws SQLException {
			Dis dis = new Dis();
			dis.setId(rs.getInt("ID"));
			dis.setNo_cis(rs.getString("NO_CIS"));
			dis.setNo_rekening(rs.getString("NO_REKENING"));
			dis.setNo_identitas(rs.getString("NO_IDENTITAS"));
			dis.setNama_nasabah(rs.getString("NAMA_NASABAH"));
			dis.setAlamat(rs.getString("ALAMAT"));
			dis.setTelpon(rs.getString("TELPON"));
			dis.setTunggakan(rs.getInt("TUNGGAKAN"));
			return dis;

		}
	}

	@Override
	public void addDis(Dis dis) {
		String SQL = "INSERT INTO DIS (" + "NO_CIS," + "NO_REKENING," + "NO_IDENTITAS," + "NAMA_NASABAH," + "ALAMAT,"
				+ "TELPON," + "TUNGGAKAN) "
				+ "VALUES (:no_cis, :no_rekening, :no_identitas, :nama_nasabah, :alamat, :telpon, :tunggakan)";
		Map<String, Object> params = new HashMap<>();
		params.put("no_cis", dis.getNo_cis());
		params.put("no_rekening", dis.getNo_rekening());
		params.put("no_identitas", dis.getNo_identitas());
		params.put("nama_nasabah", dis.getNama_nasabah());
		params.put("alamat", dis.getAlamat());
		params.put("telpon", dis.getTelpon());
		params.put("tunggakan", dis.getTunggakan());
		jdbcTemplate.update(SQL, params);
	}

	@Override
	public Dis getDisById(int Id) {
		String SQL = "SELECT * FROM DIS WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", Id);
		return jdbcTemplate.queryForObject(SQL, params, new DisMapper());
	}

	@Override
	public void updateDis(int Id, Dis dis) {
		// TODO Auto-generated method stub
		String SQL = "UPDATE DIS SET NO_CIS = :no_cis, NO_REKENING = :no_rekening, NO_IDENTITAS = :no_identitas, NAMA_NASABAH = :nama_nasabah, "
				+ "ALAMAT = :alamat, TELPON = :telpon, TUNGGAKAN = :tunggakan WHERE ID = :id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("no_cis", dis.getNo_cis());
		params.put("no_rekening", dis.getNo_rekening());
		params.put("no_identitas", dis.getNo_identitas());
		params.put("nama_nasabah", dis.getNama_nasabah());
		params.put("alamat", dis.getAlamat());
		params.put("telpon", dis.getTelpon());
		params.put("tunggakan", dis.getTunggakan());
		params.put("id", Id);
		jdbcTemplate.update(SQL, params);
	}

}
